package org.ulpgc.is1.model;

public enum ServiceType {
    Assembly, Maintenance, Repair;
}
