package org.ulpgc.is1.model;

public enum DeviceType {
    Desktop, Laptop, Mobile, Tablet;
}
